
// Author: PHNO - Tecnólogo | Pós-Graduado
// Data Release: 05/11/2024
// Versão Código: 0.0.0.2v
// Replit: @PHNO, @PHREPLIT
// E-mail: phreplit@gmail.com

// Software: PhotoSun - System - 0.0.0.2v - Sizing and Calculation for Photovoltaic System, com GUI[interface grafica] e compilacao em ambiente desktop.

package photosun.system;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
//import javafx.scene.control.Button;
//import javafx.scene.control.Label;

/**
 *
 * @author Paulo Henrique
 */
    
public class FXMLDocController implements Initializable {
    
    @FXML
    public TextField textfield;
    public TextField textfield1;
    public TextField textfield2;
    public TextField textfield3;
    public TextField textfield4;
    public TextField textfield5; 
    public TextField textfield6;
    public TextField textfield7;
    public TextField textfield8; 
    public TextField textfield9;
    public TextField textfield10;
    public TextField textfield11; 
    public TextField textfield12;
    public TextField textfield13;
    public TextField textfield14; 
    public TextField textfield15;
    public TextField textfield16;
    public TextField textfield17;
    public TextField textfield18;
    public TextField textfield19; 
    public TextField textfield20;
    public TextField textfield21;
    
    @FXML
    public void reset1(ActionEvent event) {
        textfield.setText("");
        textfield1.setText("");
        
    };
    
    @FXML
    public void reset2(ActionEvent event) {
        textfield2.setText("");
        textfield3.setText("");
        
    };
    
    @FXML
    public void reset3(ActionEvent event) {
        textfield4.setText("");
        textfield5.setText("");
        textfield6.setText("");
        
    };
    
    @FXML
    public void reset4(ActionEvent event) {
        textfield7.setText("");
        textfield8.setText("");
        textfield9.setText("");
        textfield10.setText("");
        
    };
    
    @FXML
    public void reset5(ActionEvent event) {
        textfield11.setText("");
        textfield12.setText("");
        textfield13.setText("");
        textfield14.setText("");
        
    };
    
    @FXML
    public void reset6(ActionEvent event) {
        textfield15.setText("");
        textfield16.setText("");
        textfield17.setText("");
        textfield18.setText("");
        
    };
    
    @FXML
    public void reset7(ActionEvent event) {
        textfield19.setText("");
        textfield20.setText("");
        textfield21.setText("");
        
    };
    
    @FXML
    public void calc_1(ActionEvent event) {
        int var1 = 10;
	int mult = Integer.parseInt(textfield.getText())*(var1);	
	textfield1.setText(String.valueOf(mult));

    }
    
    @FXML
    public void calc_2(ActionEvent event) {
        int var2 = 10;
	int div = Integer.parseInt(textfield2.getText())/(var2);	
	textfield3.setText(String.valueOf(div));

    }
    
    @FXML
    public void calc_3(ActionEvent event) {
         int mult2 = Integer.parseInt(textfield4.getText())*Integer.parseInt(textfield5.getText());
	 textfield6.setText(String.valueOf(mult2)); 

    }
    
    @FXML
    public void calc_4(ActionEvent event) {
         int var3 = 1000;
	 int mult3 = Integer.parseInt(textfield7.getText())*Integer.parseInt(textfield8.getText())*Integer.parseInt(textfield9.getText());
	 int result = mult3 / var3;
	 textfield10.setText(String.valueOf(result)); 

    }
    
    @FXML
    public void calc_5(ActionEvent event) {
         int var4 = 1000;
	 int mult4 = Integer.parseInt(textfield11.getText())*Integer.parseInt(textfield12.getText())*Integer.parseInt(textfield13.getText());
	 int result2 = mult4 / var4;
	 textfield14.setText(String.valueOf(result2)); 

    }
    
    @FXML
    public void calc_6(ActionEvent event) {
         int var5 = 1000;
	 int mult5 = Integer.parseInt(textfield15.getText())*Integer.parseInt(textfield16.getText())*Integer.parseInt(textfield17.getText());
	 int result3 = mult5 / var5;
	 textfield18.setText(String.valueOf(result3)); 
    }
    
    @FXML
    public void calc_7(ActionEvent event) {
         int div2 = Integer.parseInt(textfield19.getText())/Integer.parseInt(textfield20.getText());
	 textfield21.setText(String.valueOf(div2)); 

    }
    
    @FXML
    public void info(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION); // mudar para Alert.AlertType.CONFIRMATION, duas opcoes OK e CANCEL
        
        alert.setTitle("Info");
        alert.setContentText("\nBasic Conversion - To convert volts to watts we multiply the volts by 10."
+"\nBasic Conversion - To convert watts to volts we divide the watts by 10."
+"\nTo calculate the power of the modules, we multiply the nominal power of the module by the number of modules."
+"\nTo calculate weekly generation we use the calculation (power of modules) x (hours per day) x (days per week)."
+"\nTo calculate the monthly generation we use the calculation (power of the modules) x (hours per day) x (days per month)."
+"\nTo calculate the annual generation we use the calculation (power of the modules) x (hours per day) x (days per year)."
+"\nTo calculate and size the number of modules that make a solar panel, we use the following calculation:"
+"\nCalculated system power (Pfv[BR]) in watts divided by the nominal module power in watts = the Number of Modules."
+"\nTo convert 1kwh to 1wh just do the calculation e.g.: 73kwh to wh will be 73000wh. So it will be 1kwh = 1000wh.");
        alert.showAndWait();
        
        if(alert.getResult() == ButtonType.OK){
           //
        } // if (alert.getResult() == ButtonType.CANCEL) { 
         // System.exit(0); // ao clicar em cancel, sai da msg de alerta e fecha a aplicação desktop
        //}

    }
    
    @FXML
    public void about(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION); // mudar para Alert.AlertType.CONFIRMATION, duas opcoes OK e CANCEL
        
        alert.setTitle("About");
        alert.setContentText("\nSoftware: PhotoSun - Sizing and Calculation for Photovoltaic System\n"+"\nAuthor: PHNO"+"\nData Release: 08/11/2024"+"\nVersao Codigo: 0.0.0.2v"+"\nReplit: @PHNO, @PHREPLIT"+"\nE-mail: phreplit@gmail.com");
        alert.showAndWait();
        
        if(alert.getResult() == ButtonType.OK){
           //
        } // if (alert.getResult() == ButtonType.CANCEL) { 
         // System.exit(0); // ao clicar em cancel, sai da msg de alerta e fecha a aplicação desktop
        //}

    }
    
    @FXML
    public void cleardata(ActionEvent event) {
        textfield.setText("");
        textfield1.setText("");
        textfield2.setText("");
        textfield3.setText("");
        textfield4.setText("");
        textfield5.setText(""); 
        textfield6.setText("");
        textfield7.setText("");
        textfield8.setText(""); 
        textfield9.setText("");
        textfield10.setText("");
        textfield11.setText(""); 
        textfield12.setText("");
        textfield13.setText("");
        textfield14.setText(""); 
        textfield15.setText("");
        textfield16.setText("");
        textfield17.setText("");
        textfield18.setText("");
        textfield19.setText(""); 
        textfield20.setText("");
        textfield21.setText(""); 
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}